# youtube-autoupload-bot
This is a python/selenium script that can help you to upload videos in your youtube automatically.


change the chromedriver.exe with the latest one AND CHANGE THE PATHS OF



options.add_argument("user-data-dir=C:\\Users\\User\\AppData\\Local\Google\\Chrome Beta\\User Data\\")
options.binary_location = "C:\\Program Files\\Google\\Chrome Beta\\Application\\chrome.exe"

but double backslace
